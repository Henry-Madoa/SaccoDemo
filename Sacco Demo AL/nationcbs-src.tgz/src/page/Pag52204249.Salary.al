page 52204249 Salary
{
    PromotedActionCategories = 'New,Process,Report,Approval,Manual Approval,Request Approval,Workflow,Attachments,Navigate';
    PageType = Document;
    ApplicationArea = Basic, Suite;
    UsageCategory = Administration;
    SourceTable = "Checkoff Header";
    SourceTableView = where("Upload Type" = const(Salary));

    layout
    {
        area(Content)
        {
            group(General)
            {
                Editable = Rec.Status = Rec.Status::Open;

                field("No."; Rec."No.")
                {
                    ApplicationArea = Basic, Suite;
                    Editable = false;
                }
                field("Document Date"; Rec."Document Date")
                {
                    ApplicationArea = Basic, Suite;
                }
                field("Posting Date"; Rec."Posting Date")
                {
                    ApplicationArea = Basic, Suite;
                }
                field("Allow Double Recovery"; Rec."Allow Double Recovery")
                {
                    ApplicationArea = Basic, Suite;
                }
                field("Employer Code"; Rec."Employer Code")
                {
                    ApplicationArea = Basic, Suite;
                    ShowMandatory = true;
                }
                field("Income Type"; Rec."Income Type")
                {
                    ApplicationArea = Basic, Suite;
                }
                field("Search Type"; Rec."Search Type")
                {
                    ApplicationArea = Basic, Suite;
                }
                field("Sacco 360"; Rec."Sacco 360")
                {
                    ApplicationArea = Basic, Suite;
                }
                group(Sacco360)
                {
                    Visible = Rec."Sacco 360";
                    ShowCaption = false;

                    field("Bank Charges"; Rec."Bank Charges")
                    {
                        ApplicationArea = Basic, Suite;
                        ShowMandatory = true;
                    }
                    field("Bank Charges Income Account"; Rec."Bank Charges Income Account")
                    {
                        ApplicationArea = Basic, Suite;
                        ShowMandatory = true;
                    }
                }
                field(Amount; Rec.Amount)
                {
                    ApplicationArea = Basic, Suite;
                    ShowMandatory = true;
                }
                field("Posting Description"; Rec."Posting Description")
                {
                    ApplicationArea = Basic, Suite;
                    MultiLine = true;
                    ShowMandatory = true;
                }
                field("Balancing Account Type"; Rec."Balancing Account Type")
                {
                    ApplicationArea = Basic, Suite;
                }
                field("Balancing Account No"; Rec."Balancing Account No")
                {
                    ApplicationArea = Basic, Suite;
                }
                field("Suspense Account"; Rec."Suspense Account")
                {
                    ApplicationArea = Basic, Suite;
                }
                group(UploadType)
                {
                    Visible = Rec."Upload Type" = Rec."Upload Type"::Salary;
                    ShowCaption = false;

                    field("Charge Code"; Rec."Charge Code")
                    {
                        ApplicationArea = Basic, Suite;
                        ShowMandatory = true;
                    }
                }
                group(Computations)
                {
                    Editable = Rec.Status = Rec.Status::Open;

                    field("Uploaded Amount"; Rec."Uploaded Amount")
                    {
                        ApplicationArea = Basic, Suite;
                    }
                    field("Total Recoveries"; Rec."Total Recoveries")
                    {
                        ApplicationArea = Basic, Suite;
                    }
                    field(Variance; Rec.Variance)
                    {
                        ApplicationArea = Basic, Suite;
                    }
                    field("Total Members"; Rec."Total Members")
                    {
                        ApplicationArea = Basic, Suite;
                    }
                }
            }
            part("Checkoff Lines"; "Checkoff Lines")
            {
                Caption = 'Salary Lines';
                Editable = Rec.Status = Rec.Status::Open;
                ApplicationArea = Basic, Suite;
                UpdatePropagation = Both;
                SubPageLink = "No." = field("No.");
            }
            group("Audit Trail")
            {
                Editable = false;

                field("Created By"; Rec."Created By")
                {
                    ApplicationArea = Basic, Suite;
                }
                field("Created On"; Rec."Created On")
                {
                    ApplicationArea = Basic, Suite;
                }
                field(Status; Rec.Status)
                {
                    ApplicationArea = Basic, Suite;
                }
                field(Posted; Rec.Posted)
                {
                    ApplicationArea = Basic, Suite;
                }
            }
        }
        area(FactBoxes)
        {
            part("Attached Documents"; "Document Attachment Factbox")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Attachments';
                SubPageLink = "Table ID" = CONST(Database::"Checkoff Header"), "No." = FIELD("No.");
            }
            part(Control27; "Pending Approval FactBox")
            {
                ApplicationArea = Basic, Suite;
                SubPageLink = "Table ID" = CONST(Database::"Checkoff Header"), "Document No." = FIELD("No.");
                Visible = OpenApprovalEntriesExistForCurrUser;
            }
            part("Approval Entries"; "Customize Approval Entries")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Approval Entries';
                SubPageLink = "Table ID" = CONST(Database::"Checkoff Header"), "Document No." = FIELD("No.");
            }
            systempart(Control1905767507; Notes)
            {
                ApplicationArea = Notes;
            }
        }
    }
    actions
    {
        area(Navigation)
        {
            action("Upload Entries")
            {
                ApplicationArea = Basic, Suite;
                Image = EntriesList;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Category9;
                RunObject = page "Checkoff Upload Entries";
                RunPageLink = "Document No" = field("No.");
            }
            action("Upload Entries Varience")
            {
                ApplicationArea = Basic, Suite;
                Image = EntryStatistics;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Category9;
                RunObject = page "Checkoff Upload Entries";
                RunPageLink = "Document No" = field("No."), Matched = const(false);
            }
            action(Navigate)
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Find entries...';
                Image = Navigate;
                Promoted = true;
                PromotedCategory = Category9;
                ShortCutKey = 'Shift+Ctrl+I';
                ToolTip = 'Find entries and documents that exist for the document number and posting date on the selected document. (Formerly this action was named Navigate.)';
                Visible = not IsOfficeAddin and Rec.Posted;

                trigger OnAction()
                begin
                    Rec.Navigate;
                end;
            }
        }
        area(Processing)
        {
            group("Manual Approval")
            {
                Visible = NOT OpenApprovalEntriesExistForCurrUser;

                action(Reopen)
                {
                    ApplicationArea = Suite;
                    Caption = 'Re&open';
                    Enabled = ((Rec.Status = Rec.Status::Approved) and (Rec.Posted = false));
                    Image = ReOpen;
                    Promoted = true;
                    PromotedCategory = Category7;
                    PromotedOnly = true;

                    trigger OnAction()
                    begin
                        if Confirm(StrSubstNo('You are about to Re-Open %1\\Do you wish to continue?', Rec."No.")) then begin
                            Rec.Validate(Status, Rec.Status::Open);
                            Rec.Modify(true);
                            CurrPage.Close;
                        end;
                    end;
                }
            }
            group("Request Approval")
            {
                Caption = 'Request Approval';
                Visible = NOT OpenApprovalEntriesExistForCurrUser;

                action("Send Approval Request")
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Send A&pproval Request';
                    Visible = Rec.Status = Rec.Status::Open;
                    Enabled = NOT OpenApprovalEntriesExist AND CanRequestApprovalForFlow;
                    Image = SendApprovalRequest;
                    Promoted = true;
                    PromotedCategory = Category7;
                    PromotedIsBig = true;
                    PromotedOnly = true;
                    ToolTip = 'Request approval of the document.';
                    AboutTitle = 'Approval Request';
                    AboutText = 'Send the Application for Approval before creation of the Accounts by clicking **Send Approval Request**';

                    trigger OnAction();
                    begin
                        Rec.OnBeforeSendForApproval;
                        ApprovalsMgmtExt.OnSendCheckOffForApproval(Rec);
                        CurrPage.Close();
                    end;
                }
                action("Cancel Approval Request")
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Cancel Approval Re&quest';
                    Visible = Rec.Status = Rec.Status::"Pending Approval";
                    Enabled = CanCancelApprovalForRecord OR CanCancelApprovalForFlow;
                    Image = CancelApprovalRequest;
                    Promoted = true;
                    PromotedCategory = Category7;
                    PromotedOnly = true;
                    ToolTip = 'Cancel the approval request.';
                    AboutTitle = 'Cancel Approval Request';
                    AboutText = 'Incase of Corrections recall the document by clicking **Cancel Approval Request**';

                    trigger OnAction();
                    begin
                        ApprovalsMgmtExt.OnCancelCheckOffForApproval(Rec);
                        CurrPage.Close();
                    end;
                }
            }
            group(Approval)
            {
                Caption = 'Approval';

                action(Approve)
                {
                    ApplicationArea = Suite;
                    Caption = 'Approve';
                    Image = Approve;
                    Promoted = true;
                    PromotedCategory = Category4;
                    PromotedIsBig = true;
                    PromotedOnly = true;
                    ToolTip = 'Approve the requested changes.';
                    Visible = OpenApprovalEntriesExistForCurrUser;

                    trigger OnAction()
                    var
                        ApprovalsMgmt: Codeunit "Approvals Mgmt.";
                        Text001: Label 'You are about to approve the document, Do you wish to continue';
                        Text002: Label 'You have approved the document';
                    begin
                        if Confirm(Text001, false) = true then begin
                            ApprovalsMgmt.ApproveRecordApprovalRequest(Rec.RecordId);
                            Message(Text002);
                            CurrPage.Close();
                        end
                        else
                            exit;
                    end;
                }
                action(Reject)
                {
                    ApplicationArea = Suite;
                    Caption = 'Reject';
                    Image = Reject;
                    Promoted = true;
                    PromotedCategory = Category4;
                    PromotedIsBig = true;
                    PromotedOnly = true;
                    ToolTip = 'Reject the requested changes.';
                    Visible = OpenApprovalEntriesExistForCurrUser;

                    trigger OnAction()
                    var
                        ApprovalsMgmt: Codeunit "Approvals Mgmt.";
                        ApprovalMgmt_Ext: Codeunit "Approval Mgmt. Ext";
                        Text001: Label 'You are about to Reject the document, Do you wish to continue';
                        Text002: Label 'You have rejected the document';
                    begin
                        if Confirm(Text001, false) = true then begin
                            ApprovalsMgmt.RejectRecordApprovalRequest(Rec.RecordId);
                            Message(Text002);
                            CurrPage.Close();
                        end
                        else
                            exit;
                    end;
                }
                action(Delegate)
                {
                    ApplicationArea = Suite;
                    Caption = 'Delegate';
                    Image = Delegate;
                    Promoted = true;
                    PromotedCategory = Category4;
                    PromotedOnly = true;
                    ToolTip = 'Delegate the requested changes to the substitute approver.';
                    Visible = OpenApprovalEntriesExistForCurrUser;

                    trigger OnAction()
                    var
                        ApprovalsMgmt: Codeunit "Approvals Mgmt.";
                        Text001: Label 'You are about to Delegate the document, Do you wish to continue';
                        Text002: Label 'You have delegated the document';
                    begin
                        if Confirm(Text001, false) = true then begin
                            ApprovalsMgmt.DelegateRecordApprovalRequest(Rec.RecordId);
                            Message(Text002);
                            CurrPage.Close();
                        end
                        else
                            exit;
                    end;
                }
                action(Comment)
                {
                    ApplicationArea = Suite;
                    Caption = 'Comments';
                    Image = ViewComments;
                    Promoted = true;
                    PromotedCategory = Category4;
                    PromotedOnly = true;
                    ToolTip = 'View or add comments for the record.';
                    Visible = OpenApprovalEntriesExistForCurrUser;

                    trigger OnAction()
                    var
                        ApprovalsMgmt: Codeunit "Approvals Mgmt.";
                    begin
                        ApprovalsMgmt.GetApprovalComment(Rec);
                    end;
                }
            }
            group("Approval Details")
            {
                Visible = NOT OpenApprovalEntriesExistForCurrUser;
                Caption = 'Approvals';

                action(Approvals)
                {
                    //AccessByPermission = TableData "Approval Entry" = R;
                    ApplicationArea = Suite;
                    Caption = 'Approvals';
                    Image = Approvals;
                    Promoted = true;
                    PromotedOnly = true;
                    PromotedCategory = Category7;
                    ToolTip = 'View a list of the records that are waiting to be approved. For example, you can see who requested the record to be approved, when it was sent, and when it is due to be approved.';

                    trigger OnAction()
                    var
                        ApprovalsMgmt: Codeunit "Approvals Mgmt.";
                    begin
                        ApprovalsMgmt.OpenApprovalEntriesPage(Rec.RecordId);
                    end;
                }
            }
            action(DocAttach)
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Attachments';
                Image = Attach;
                Promoted = true;
                PromotedCategory = Category8;
                ToolTip = 'Add a file as an attachment. You can attach images as well as documents.';

                trigger OnAction()
                var
                    DocumentAttachmentDetails: Page "Document Attachment Details";
                    RecRef: RecordRef;
                begin
                    RecRef.GetTable(Rec);
                    DocumentAttachmentDetails.OpenForRecRef(RecRef);
                    DocumentAttachmentDetails.RunModal;
                end;
            }
            action("Apply Employer Upload")
            {
                ApplicationArea = Basic, Suite;
                Image = Import;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Visible = Rec.Status = Rec.Status::Open;
                trigger OnAction()
                var
                    CheckOff: Codeunit "Checkoff Management";
                begin
                    CheckOff.ApplyEmployerUpload(Rec."No.");
                end;
            }
            action(Import)
            {
                ApplicationArea = Basic, Suite;
                Image = Import;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Visible = Rec.Status = Rec.Status::Open;

                trigger OnAction()
                var
                    CheckOffUpload: Record "Checkoff Upload";
                begin
                    CheckOffUpload.Reset();
                    CheckOffUpload.SetRange("Document No", Rec."No.");
                    if CheckOffUpload.FindSet() then CheckOffUpload.DeleteAll();
                    Commit();
                    Clear(Import);
                    Import.SetCheckoffNo(Rec."No.");
                    Import.Run();
                    ;
                end;
            }
            action("Validate Upload")
            {
                Image = CheckDuplicates;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Visible = Rec.Status = Rec.Status::Open;

                trigger OnAction()
                var
                    CheckOff: Codeunit "Checkoff Management";
                begin
                    CheckOff.ValidateUpload(Rec."No.");
                end;
            }
            action(Calculate)
            {
                Image = Calculate;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Visible = Rec.Status = Rec.Status::Open;

                trigger OnAction()
                var
                    CheckOff: Codeunit "Checkoff Management";
                begin
                    CheckOff.CalculateRecoveries(Rec."No.");
                end;
            }
            action(Post)
            {
                Image = PostApplication;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Visible = ((Rec.Status = Rec.Status::Approved) and (not Rec.Posted));

                trigger OnAction()
                var
                    CheckOff: Codeunit "Checkoff Management";
                begin
                    Rec.TestField(Rec.Status, Rec.Status::Approved);
                    if Confirm('Do you want to Post?') then begin
                        CheckOff.PostCheckoff(Rec."No.");
                    end;
                end;
            }
            action("Send SMS")
            {
                Image = SendAsPDF;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Visible = ((Rec.Status = Rec.Status::Approved) and (Rec.Posted));

                trigger OnAction()
                var
                    CheckOff: Codeunit "Checkoff Management";
                begin
                    Rec.TestField(Rec.Status, Rec.Status::Approved);
                    if Confirm('Do you want to Resend SMS?') then begin
                        CheckOff.SendSalarySMS(Rec."No.");
                    end;
                end;
            }
            action(Post_Update)
            {
                Image = PostApplication;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Visible = false;

                trigger OnAction()
                var
                    CheckOff: Codeunit "Checkoff Management";
                begin
                    Rec.TestField(Rec.Status, Rec.Status::Approved);
                    if Confirm('Do you want to Update Post?') then begin
                        OnAfter_PostCheckoff(Rec."No.");
                    end;
                end;
            }
        }
    }
    trigger OnNewRecord(BelowxRec: Boolean)
    begin
        Rec."Upload Type" := Rec."Upload Type"::Salary;
        Rec."Balancing Account Type" := Rec."Balancing Account Type"::"Bank Account";
    end;

    trigger OnOpenPage()
    begin
        SetControlAppearance;
    end;

    trigger OnAfterGetRecord()
    begin
        SetControlAppearance;
    end;

    trigger OnAfterGetCurrRecord()
    begin
        SetControlAppearance;
    end;

    local procedure SetControlAppearance()
    var
        ApprovalsMgmt: Codeunit "Approvals Mgmt.";
        WorkflowWebhookMgt: Codeunit "Workflow Webhook Management";
    begin
        OpenApprovalEntriesExistForCurrUser := ApprovalsMgmt.HasOpenApprovalEntriesForCurrentUser(Rec.RecordId);
        OpenApprovalEntriesExist := ApprovalsMgmt.HasOpenApprovalEntries(Rec.RecordId);
        CanCancelApprovalForRecord := ApprovalsMgmt.CanCancelApprovalForRecord(Rec.RecordId);
        WorkflowWebhookMgt.GetCanRequestAndCanCancel(Rec.RecordId, CanRequestApprovalForFlow, CanCancelApprovalForFlow);
        IsOfficeAddin := OfficeMgt.IsAvailable;
    end;

    var
        OpenApprovalEntriesExistForCurrUser: Boolean;
        OpenApprovalEntriesExist: Boolean;
        CanCancelApprovalForRecord: Boolean;
        CanRequestApprovalForFlow: Boolean;
        CanCancelApprovalForFlow: Boolean;
        OfficeMgt: Codeunit "Office Management";
        IsOfficeAddin: Boolean;
        Import: XmlPort "Import Checkoff";
        ApprovalsMgmtExt: Codeunit "Approval Mgmt. CBS Ext";

    procedure OnAfter_PostCheckoff(CheckoffNo: Code[20])
    var
        CheckoffHeader: Record "Checkoff Header";
        CheckoffCalculation: Record "Checkoff Calculation";
    begin
        if CheckoffHeader.Get(CheckoffNo) then begin
            CheckoffCalculation.Reset();
            CheckoffCalculation.SetRange("Document No", CheckoffNo);
            if CheckoffCalculation.FindSet() then begin
                repeat
                    CheckoffCalculation."Pay Period" := CalcDate('CM', CheckoffHeader."Posting Date");
                    CheckoffCalculation.Posted := true;
                    CheckoffCalculation.Modify(true);
                until CheckoffCalculation.Next = 0;
            end;
        end;
    end;
}
